# BGB Group of Schools — HTML Website

This is a static HTML/CSS/JavaScript website starter for BGB Group of Schools.

## Folder Structure

- `index.html` — Homepage
- `assets/css/style.css` — Main stylesheet
- `assets/js/main.js` — Navigation and animations
- `assets/images/` — Add your school photos here
- `pages/` — Inner pages

## How to use on GitHub Pages

1. Create a new GitHub repository.
2. Upload the contents of this folder.
3. Make sure `index.html` is in the repository root.
4. Go to **Settings → Pages**.
5. Select the main branch and root folder.
6. Save.

## Important

Replace the placeholder phone numbers and email address before publishing.

Add real BGB photos to:

- `assets/images/hero.jpg`
- `assets/images/campus.jpg`

Then continue building the inner pages.
